/*!
 * 
 * ap/v1.7.1
 * Wed Apr 18 2018 19:52:10 GMT+0800 (CST)
 * 
 */
var global = self,
    __appxStartTime = (global = self, Date.now()),
    AFAppX = function(e) {
        var t = {};

        function n(a) {
            if (t[a]) return t[a].exports;
            var r = t[a] = {
                i: a,
                l: !1,
                exports: {}
            };
            return e[a].call(r.exports, r, r.exports, n), r.l = !0, r.exports
        }
        return n.m = e, n.c = t, n.d = function(e, t, a) {
            n.o(e, t) || Object.defineProperty(e, t, {
                configurable: !1,
                enumerable: !0,
                get: a
            })
        }, n.r = function(e) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            })
        }, n.n = function(e) {
            var t = e && e.__esModule ? function() {
                return e.default
            } : function() {
                return e
            };
            return n.d(t, "a", t), t
        }, n.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t)
        }, n.p = "", n(n.s = 22)
    }([function(e, t, n) {
        "use strict";
        var a = self,
            r = void 0;
        var i = n(16);
        var o = n(6),
            c = n(4),
            s = n(2);
        n.d(t, "d", function() {
            return c.d
        }), n.d(t, "f", function() {
            return c.f
        }), n.d(t, "b", function() {
            return c.b
        }), n.d(t, "j", function() {
            return c.j
        }), n.d(t, "h", function() {
            return c.h
        }), n.d(t, "i", function() {
            return c.i
        }), n.d(t, "g", function() {
            return c.g
        }), n.d(t, "k", function() {
            return c.k
        }), n.d(t, "m", function() {
            return c.m
        }), n.d(t, "c", function() {
            return c.c
        }), n.d(t, "a", function() {
            return c.a
        }), n.d(t, "l", function() {
            return c.l
        }), n.d(t, "e", function() {
            return c.e
        });
        var u = self;
        u.onerror = function() {
            var e = (arguments.length <= 0 ? void 0 : arguments[0]) || 0;
            try {
                var t = Object(c.g)();
                t && t.error(e)
            } catch (e) {
                console.error("[WORKER] report catch error", e)
            }
            console.error("[WORKER] onerror", e)
        }, u.bootstrapApp = function(e) {
            var t = e.success;

            function n() {
                if (Object(c.k)().allowEval || function() {
                        var e = global;
                        if ("undefined" != typeof Function) {
                            Function.constructor = function() {}, Function.prototype.constructor = function() {}, e.Function = function() {
                                if (arguments.length > 0 && -1 !== arguments[arguments.length - 1].indexOf("return this")) return function() {
                                    return {}
                                }
                            };
                            var t = Function.constructor.__proto__;
                            t && Object.defineProperty(t, "apply", {
                                writable: !1,
                                configurable: !1,
                                value: Function.prototype.constructor.apply
                            })
                        }
                        e.eval = null;
                        var n = setTimeout,
                            a = setInterval;
                        e.setTimeout = function(e, t) {
                            if ("function" == typeof e) return n(e, t)
                        }, e.setInterval = function(e, t) {
                            if ("function" == typeof e) return a(e, t)
                        }
                    }(), !o.d && !o.e && !Object(c.k)().enablePolyfillWorker) {
                    var e = s.a.callInternalAPISync("getStartupParams") || {};
                    e.appId ? Object(c.m)(e) : console.error("callInternalAPISync getStartupParams error", e)
                }
                t()
            }
            if (o.e || !Object(c.k)().isNotTinyProcess || Object(c.k)().enablePolyfillWorker) return n();
            Object(i.b)(),
                function e(t, n) {
                    if (r) return t(r);
                    a.registration.pushManager.getSubscription().then(function(a) {
                        a && a.applicationId ? (r = a.applicationId, t(r)) : setTimeout(function() {
                            e(t, n)
                        }, 150)
                    }).catch(function(e) {
                        n("getApplicationId fail: " + e.message)
                    })
                }(function() {
                    n(), Object(i.a)()
                }, function(e) {})
        }
    }, function(e, t) {
        const n = Array.prototype.slice;
        e.exports = function(e) {
            return n.call(arguments, 1).forEach(function(t) {
                t && "object" == typeof t && Object.keys(t).forEach(function(n) {
                    e[n] = t[n]
                })
            }), e
        }
    }, function(e, t, n) {
        "use strict";
        var a = n(8);
        a.a.callInternalAPI = function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                n = arguments[2];
            a.a.callBridge(e, t, n)
        }, a.a.callInternalAPISync = function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return a.a.callBridgeSync && a.a.callBridgeSync(e, t) || {}
        }, t.a = a.a
    }, function(e, t, n) {
        "use strict";
        var a = {},
            r = {
                tabsConfig: {},
                pagesConfig: {},
                currentPageConfig: {},
                listeners: a,
                addEventListener: function(e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                        r = e;
                    Array.isArray(r) || (r = [r]);
                    var i = [];
                    return r.forEach(function(e) {
                            var r = a[e] = a[e] || [];
                            n.first ? r.unshift(t) : r.push(t), i.push({
                                fns: r,
                                fn: t
                            })
                        }),
                        function() {
                            i.forEach(function(e) {
                                var t = e.fns,
                                    n = e.fn,
                                    a = t.indexOf(n); - 1 !== a && t.splice(a, 1)
                            })
                        }
                },
                dispatchEvent: function(e, t) {
                    var n = e;
                    Array.isArray(n) || (n = [n]), n.forEach(function(e) {
                        var n = a[e];
                        n && n.forEach(function(e) {
                            return e(t)
                        })
                    })
                }
            };
        global.$global = r, t.a = r
    }, function(e, t, n) {
        "use strict";
        var a = n(1),
            r = n.n(a);
        if (!global.Symbol) {
            var i = 0,
                o = function(e) {
                    return "$$_appx_symbol_" + e + "_" + ++i + "_$$"
                };
            o.iterator = o("Symbol.iterator"), global.Symbol = o
        }
        Object.assign = r.a;
        n(16);
        var c = {},
            s = {
                registerComponent: function(e, t) {
                    c[e] = t
                },
                getComponent: function(e) {
                    return c[e] && c[e]()
                }
            };

        function u(e) {
            return s.getComponent(e)
        }
        var l = n(3);

        function p(e, t) {
            return t.forEach(function(t) {
                -1 === e.indexOf(t) && e.push(t)
            }), e
        }
        var f = n(14),
            d = n(5);

        function h(e, t) {
            return e ? function(e) {
                return Array.isArray(e)
            }(e) ? e.slice() : r()({}, e) : t ? [] : {}
        }

        function g(e, t) {
            var n = r()({}, e);
            return Object(d.a)(t).forEach(function(e) {
                    var a = Object(f.a)(e);
                    ! function e(t, n, a, r, i) {
                        var o = a[0];
                        return (i && t === n || !t) && (t = h(n, "number" == typeof o)), 1 === a.length ? r(t, o) : (n && (n = n[o]), t[o] = e(t[o], n, a.slice(1), r, !0), t)
                    }(n, n, a, function(n, a) {
                        return n[a] = t[e], n
                    })
                }),
                function(e, t) {
                    if (e === t) return !0;
                    if ("object" != typeof e || null === e || "object" != typeof t || null === t) return !1;
                    var n = Object(d.a)(e),
                        a = Object(d.a)(t),
                        r = n.length;
                    if (r !== a.length) return !1;
                    for (var i = 0; i < r; i++) {
                        var o = n[i];
                        if (!t.hasOwnProperty(o)) return !1;
                        if (e[o] !== t[o]) return !1
                    }
                    return !0
                }(n, e) ? e : n
        }
        var v = n(13),
            b = [],
            m = {
                getComputedData: function(e, t) {
                    this.computedDeps = this.computedDeps || {};
                    var n = {},
                        a = !1,
                        r = this.computedDeps,
                        i = e.computed,
                        o = e.data;
                    return i && Object(d.a)(i).forEach(function(e) {
                        var c = i[e],
                            s = c.slice(-1)[0],
                            u = c.slice(0, -1),
                            l = !1;
                        if ("function" == typeof s) {
                            var p = [];
                            u.length ? (p = u.map(function(e) {
                                return Object(v.a)(o, e)
                            }), (l = !r[e] || r[e].some(function(e, t) {
                                return e !== p[t]
                            })) && (r[e] = p)) : r[e] || (l = !0, r[e] = b), (t || l) && (n[e] = s.apply(null, p), a = !0)
                        }
                    }), a ? n : void 0
                }
            };

        function y(e, t, n) {
            t && Object(d.a)(t).forEach(function(a) {
                if (a in e) throw new Error("Tried to merge two objects with the same key: `" + a + "`. This conflict is due to `" + n + "` of a component mixin.");
                e[a] = t[a]
            })
        }

        function I(e, t, n, a) {
            var r = e.mixins;
            (void 0 === r ? [] : r).forEach(function(e) {
                e[n] && e[n].apply(t, a)
            }), e[n] && e[n].apply(t, a)
        }
        var C = /^on[A-Z]/;

        function P(e) {
            var t = void 0,
                n = l.a.currentComponentConfig,
                a = n.is,
                i = n.usingComponents;
            s.registerComponent(a, function() {
                if (t) return t;
                var n = {},
                    o = function(t) {
                        var a = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                        return function(e, t, n) {
                            if (n && n[t]) return n[t];
                            var a = e.mixins,
                                r = {};
                            (void 0 === a ? [] : a).forEach(function(e) {
                                var n = e[t];
                                "function" == typeof n && (n = n()), y(r, n, t)
                            });
                            var i = e[t];
                            return "function" == typeof i && (i = i()), y(r, i, t), n && (n[t] = r), r
                        }(e, t, a ? n : a)
                    };
                (t = function(e, n, i) {
                    this.is = a, this.id = n, this.page = e, this.triggerEventHandlers = {};
                    var c = this.publicInstance = Object.create(o("methods"));
                    c.setData = this.setData.bind(this), c.is = a, c.$id = n, c.$page = e.publicInstance, c.data = o("data", !1), this.computedDeps = r()({}, t.computedDeps), this.prevData = c.data, c.props = o("props"), this.setComponentConfig(i, !0)
                }).data = o("data"), t.computedData = m.getComputedData.call(t, {
                    data: t.data,
                    computed: o("computed")
                }, !0), t.props = o("props");
                var c = void 0;
                return t.getAllComponents = function() {
                    return c || (c = [a], Object(d.a)(i).forEach(function(e) {
                        var t = u(i[e]).getAllComponents();
                        p(c, t)
                    }), c)
                }, t.prototype = {
                    setData: function(e, t) {
                        var n = this.id,
                            a = this.publicInstance;
                        this.prevData = a.data, a.data = g(a.data, e), this.page.setRemoteData({
                            type: "component",
                            id: n,
                            data: e
                        }, t)
                    },
                    getComputedData: function() {
                        return m.getComputedData.call(this, this.publicInstance)
                    },
                    setComponentConfig: function(e, t) {
                        var n = e.ownerId,
                            a = e.diffProps;
                        n && (this.ownerId = n);
                        var i = this.publicInstance,
                            o = i.props;
                        if (a) {
                            var c = a.deleted,
                                s = a.updated;
                            (c && c.length || s && Object(d.a)(s).length) && (i.props = r()({}, i.props)), c && c.forEach(function(e) {
                                delete i.props[e]
                            }), s && r()(i.props, this.normalizeProps(s))
                        }
                        t || o === i.props && this.prevData === i.data || (this.update(o, this.prevData), this.prevData = i.data)
                    },
                    normalizeProps: function(e) {
                        var t = this,
                            n = r()({}, e);
                        return Object(d.a)(e).forEach(function(a) {
                            a.match(C) && (n[a] = t.getTriggerEventHandler(a, e[a]))
                        }), n
                    },
                    getTriggerEventHandler: function(e, t) {
                        var n = this,
                            a = this.triggerEventHandlers;
                        return a[e] ? (a[e].eventHandler = t, a[e]) : (a[e] = function() {
                            for (var t = arguments.length, a = Array(t), r = 0; r < t; r++) a[r] = arguments[r];
                            return n.triggerEvent.apply(n, [e].concat(a))
                        }, a[e].eventHandler = t, a[e])
                    },
                    triggerEvent: function(e) {
                        var t = this.page.getComponentInstance(this.ownerId),
                            n = this.publicInstance.props[e].eventHandler;
                        if (t && t.publicInstance[n]) {
                            for (var a, r = arguments.length, i = Array(r > 1 ? r - 1 : 0), o = 1; o < r; o++) i[o - 1] = arguments[o];
                            return (a = t.publicInstance)[n].apply(a, i)
                        }
                    },
                    ready: function() {
                        I(e, this.publicInstance, "didMount")
                    },
                    update: function() {
                        for (var t = arguments.length, n = Array(t), a = 0; a < t; a++) n[a] = arguments[a];
                        I(e, this.publicInstance, "didUpdate", n)
                    },
                    unload: function() {
                        I(e, this.publicInstance, "didUnmount")
                    }
                }, t
            })
        }
        var O = n(7);

        function k() {}
        var w = n(15);

        function j(e, t, n) {
            var a = void 0,
                r = void 0,
                i = void 0,
                o = void 0,
                c = void 0,
                s = void 0,
                u = 0,
                l = !1,
                p = !1,
                f = !0,
                d = !t && 0 !== t && "function" == typeof requestAnimationFrame;

            function h(t) {
                var n = a,
                    i = r;
                return a = r = void 0, u = t, o = e.apply(i, n)
            }

            function g(e, t) {
                return d ? requestAnimationFrame(e) : setTimeout(e, t)
            }

            function v(e) {
                var n = e - s;
                return void 0 === s || n >= t || n < 0 || p && e - u >= i
            }

            function b() {
                var e = Date.now();
                if (v(e)) return m(e);
                c = g(b, function(e) {
                    var n = e - u,
                        a = t - (e - s);
                    return p ? Math.min(a, i - n) : a
                }(e))
            }

            function m(e) {
                return c = void 0, f && a ? h(e) : (a = r = void 0, o)
            }
            t = +t || 0, n && (l = n.leading, i = (p = "maxWait" in n) ? Math.max(+n.maxWait || 0, t) : i, f = "trailing" in n ? n.trailing : f);
            var y = function() {
                for (var e = Date.now(), n = v(e), i = arguments.length, f = Array(i), d = 0; d < i; d++) f[d] = arguments[d];
                if (a = f, r = this, s = e, n) {
                    if (void 0 === c) return function(e) {
                        return u = e, c = g(b, t), l ? h(e) : o
                    }(s);
                    if (p) return c = g(b, t), h(s)
                }
                return void 0 === c && (c = g(b, t)), o
            };
            return y.cancel = function() {
                void 0 !== c && function(e) {
                    if (d) return cancelAnimationFrame(e);
                    clearTimeout(e)
                }(c), u = 0, a = s = r = c = void 0
            }, y.flush = function() {
                return void 0 === c ? o : m(Date.now())
            }, y.pending = function() {
                return void 0 !== c
            }, y
        }
        var T = ["onShareAppMessage", "onReachBottom", "onPageScroll"];
        var A = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = l.a.bridge,
                    n = l.a.tabsConfig,
                    a = l.a.currentPageConfig,
                    i = l.a.pagesConfig,
                    o = a.pagePath,
                    c = a.tabIndex,
                    s = a.usingComponents,
                    f = void 0 === s ? {} : s;
                c && (n[o] = c), i[o] = a;
                var h = void 0,
                    v = r()({
                        route: o
                    }, e);
                w.a.registerComponent(o, function() {
                    if (h) return h;

                    function e(n) {
                        var a, i, o, c, s, u = n.port,
                            l = n.id,
                            p = n.query;
                        if (!(this instanceof e)) return new e({
                            port: u,
                            id: l,
                            query: p
                        });
                        this.$startTime = Date.now(), this.onMessage = this.onMessage.bind(this), this.flushData = (a = this.flushData.bind(this), i = 30, c = !0, s = !0, o && (c = "leading" in o ? o.leading : c, s = "trailing" in o ? o.trailing : s), j(a, i, {
                            leading: c,
                            maxWait: i,
                            trailing: s
                        })), this.componentInstances = {}, this.nativeComponents = {}, u && this.setPort(u), r()(this, {
                            id: l,
                            bridge: t,
                            pendingData: [],
                            pendingCallbacks: [],
                            initialCallbacks: [],
                            self: this,
                            query: p
                        });
                        var f = this.publicInstance = Object.create(v, {
                            setData: {
                                value: this.setData.bind(this)
                            },
                            $getComponentBy: {
                                value: this.getComponentBy.bind(this)
                            }
                        });
                        "function" == typeof f.data && (f.data = f.data() || {})
                    }
                    var n = void 0;
                    return e.prototype = r()({}, function(e) {
                        var t = e.type,
                            n = e.pagePath,
                            a = 0,
                            r = {};

                        function i() {
                            return a += 2
                        }
                        return {
                            setId: function(e) {
                                this.id = e
                            },
                            getId: function() {
                                return this.id
                            },
                            getPagePath: function() {
                                return n
                            },
                            onMessage: function(e) {
                                var a = this;
                                if (!this.unloaded) {
                                    var r = e.data;
                                    "string" == typeof r && (r = JSON.parse(r).data);
                                    var i = r,
                                        o = i.method,
                                        c = i.args,
                                        s = i.caller,
                                        u = i.successCallback,
                                        l = i.errorCallback;
                                    "bridge" === s && "console" === o || Object(O.a)("framework", "[" + t + "] Page " + n + " onMessage", r);
                                    var p = this;
                                    if ((s && s.split(".") || []).forEach(function(e) {
                                            p = p && p[e]
                                        }), p) {
                                        var f, d = c.concat();
                                        if (u ? d.push(function() {
                                                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                                                a.callRemote.apply(a, ["self", "invokeCallback", u].concat(t))
                                            }) : d.push(k), l ? d.push(function() {
                                                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                                                a.callRemote.apply(a, ["self", "invokeCallback", l].concat(t))
                                            }) : d.push(k), p[o]) return void(f = p)[o].apply(f, d)
                                    }
                                    Object(O.a)("framework", "[" + t + "] Page " + n + " unhandled message", e.data)
                                }
                            },
                            invokeCallback: function(e) {
                                if (!this.unloaded) {
                                    if (e && r[e]) {
                                        for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++) n[a - 1] = arguments[a];
                                        r[e].apply(r, n)
                                    }
                                    e % 2 == 0 && (e -= 1), delete r[e], delete r[e + 1]
                                }
                            },
                            callRemote: function(e, t) {
                                for (var n = arguments.length, a = Array(n > 2 ? n - 2 : 0), o = 2; o < n; o++) a[o - 2] = arguments[o];
                                if (!this.unloaded) {
                                    var c = void 0,
                                        s = void 0;
                                    "function" == typeof a[a.length - 2] ? (c = i() - 1, r[c] = a[a.length - 2], r[s = c + 1] = a[a.length - 1], a.pop(), a.pop()) : "function" == typeof a[a.length - 1] && (c = i() - 1, r[c] = a[a.length - 1], s = c + 1, a.pop()), this.postMessage({
                                        caller: e,
                                        method: t,
                                        id: this.getId(),
                                        successCallback: c,
                                        errorCallback: s,
                                        args: a
                                    })
                                }
                            }
                        }
                    }({
                        pagePath: o,
                        type: "WORKER"
                    }), m, {
                        load: function() {
                            if (!this.$loadTime) {
                                this.$loadTime = Date.now();
                                var e = this.publicInstance;
                                this._disableRemoteData = !0, Object(O.b)("framework: page onLoad", o), l.a.dispatchEvent("pageLoad", {
                                    page: this
                                }), e.onLoad && e.onLoad(this.query), this.show(), this._fromTabItemTap && this.tabItemTap(), this._disableRemoteData = !1
                            }
                            this.startRender()
                        },
                        show: function() {
                            if (!this.unloaded) return this.$loadTime ? void(this.shown || (this.shown = !0, l.a.dispatchEvent("enterPage", {
                                page: this
                            }), this.publicInstance.onShow && this.publicInstance.onShow(), Object(O.b)("framework: page onShow", o))) : this.load()
                        },
                        pullDownRefresh: function() {
                            var e = this.publicInstance;
                            l.a.dispatchEvent("pullDownRefresh", {
                                page: this
                            }), e.onPullDownRefresh && e.onPullDownRefresh()
                        },
                        hide: function() {
                            this.unloaded || this.$loadTime && this.shown && (this.shown = !1, l.a.dispatchEvent("leavePage", {
                                page: this
                            }), l.a.dispatchEvent("pageHide", {
                                page: this
                            }), this.publicInstance.onHide && this.publicInstance.onHide(), Object(O.b)("framework: page onHide", o))
                        },
                        unload: function() {
                            var e = this;
                            Object(O.b)("framework: page onUnload", o), !this.unloaded && this.$loadTime ? (this.unloaded = !0, this.clearPort(), Object(d.a)(this.componentInstances).forEach(function(t) {
                                e.componentInstances[t].unload()
                            }), this.componentInstances = {}, this.publicInstance.onUnload && this.publicInstance.onUnload(), l.a.dispatchEvent("leavePage", {
                                page: this
                            }), l.a.dispatchEvent("pageUnload", {
                                page: this
                            }), this.flushData.cancel()) : l.a.dispatchEvent("pageUnload", {
                                page: this
                            })
                        },
                        isLoaded: function() {
                            return !!this.$loadTime && !this.unloaded
                        },
                        callBridge: function(e, t, n, a) {
                            this.bridge[e] ? this.bridge[e](r()({}, t, {
                                success: n,
                                fail: a
                            })) : a({
                                error: 1,
                                errorMessage: "not implemented!"
                            })
                        },
                        startRender: function() {
                            var e = this.publicInstance,
                                t = this.id,
                                a = {};
                            T.forEach(function(t) {
                                var n = e[t];
                                "function" == typeof n && n !== function() {} && (a[t] = !0)
                            });
                            var i = {};
                            f && (n || (n = [], Object(d.a)(f).forEach(function(e) {
                                var t = u(f[e]).getAllComponents();
                                p(n, t)
                            }), n)).forEach(function(e) {
                                var t = u(e);
                                i[e] = {
                                    props: t.props,
                                    data: r()({}, t.data, t.computedData)
                                }
                            }), this.callRemote("self", "startRender", {
                                id: t,
                                publicInstance: a,
                                componentsConfig: i,
                                data: r()({}, this.getComputedData(this.publicInstance, !0), e.data)
                            })
                        },
                        getComponentInstance: function(e) {
                            return "1" === String(e) ? this : this.componentInstances[e]
                        },
                        getComponentBy: function(e) {
                            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                                n = [],
                                a = this.componentInstances;
                            if (a)
                                for (var r = Object(d.a)(a), i = 0; i < r.length; i++) {
                                    var o = a[r[i]].publicInstance;
                                    if (e(o) && (n.push(o), t.returnOnFirstMatch)) return n
                                }
                            return n
                        },
                        triggerComponentEvent: function(e, t, n) {
                            var a = this.getComponentInstance(e);
                            a && a.publicInstance[t](n)
                        },
                        tabItemTap: function() {
                            if (c) {
                                var e = this.publicInstance;
                                e.onTabItemTap && e.onTabItemTap({
                                    index: c - 10,
                                    pagePath: o
                                })
                            }
                        },
                        updateComponents: function(e) {
                            var t = this,
                                n = e.mountedComponents,
                                a = e.unmountedComponents,
                                r = this.componentInstances;
                            Object(d.a)(n).reverse().forEach(function(e) {
                                var a = n[e];
                                if (r[e]) r[e].setComponentConfig(a);
                                else {
                                    var i = u(a.is);
                                    r[e] = new i(t, e, a), r[e].ready()
                                }
                            }), a.concat().reverse().forEach(function(e) {
                                r[e] && (r[e].unload(), delete r[e])
                            })
                        },
                        updateNativeComponents: function(e) {
                            var t = this,
                                n = e.mountedNativeComponents,
                                a = e.unmountedNativeComponents;
                            r()(this.nativeComponents, n), a.forEach(function(e) {
                                delete t.nativeComponents[e]
                            })
                        },
                        ready: function(e) {
                            this.unloaded || this.readied || (this.readied = !0, this.updateComponents(e), this.updateNativeComponents(e), l.a.dispatchEvent("pageReady", {
                                page: this
                            }), this.initialCallbacks.forEach(function(e) {
                                return e()
                            }), this.publicInstance.onReady && this.publicInstance.onReady(), Object(O.b)("framework: page onReady", o))
                        },
                        update: function(e) {
                            this.updateComponents(e), this.updateNativeComponents(e)
                        },
                        postMessage: function(e) {
                            !this.unloaded && this.port && (Object(O.a)("framework", "[WORKER] Page " + o + " postMessage", e), this.port.postMessage(JSON.stringify({
                                data: e
                            })))
                        },
                        console: function(e) {
                            function t(t) {
                                return e.apply(this, arguments)
                            }
                            return t.toString = function() {
                                return e.toString()
                            }, t
                        }(function(e) {
                            console[e].apply(console, [].slice.call(arguments, 1, -2))
                        }),
                        clearPort: function() {
                            this.port && (this.port.onmessage = null, this.port = null)
                        },
                        setPort: function(e) {
                            this.port !== e && (this.clearPort(), this.port = e, e.onmessage = this.onMessage)
                        },
                        setData: function(e, t) {
                            this.unloaded ? console.log('setData(...) can only update a loaded page. This usually means you called setData() on a unloaded page. Please check the code for the "' + o + '" page.') : e && (this.publicInstance.data = g(this.publicInstance.data, e), this._disableRemoteData ? t && this.initialCallbacks.push(t) : this.setRemoteData({
                                type: "page",
                                data: e
                            }, t))
                        },
                        setRemoteData: function(e, t) {
                            this.pendingData.push(e), t && this.pendingCallbacks.push(t), this.flushData()
                        },
                        flushData: function() {
                            var e = this.pendingData,
                                t = this.componentInstances,
                                n = this.pendingCallbacks;
                            this.pendingData = [], this.pendingCallbacks = [];
                            var a = void 0,
                                r = void 0,
                                i = [];
                            e.forEach(function(e) {
                                var t = e.type,
                                    n = e.id;
                                "page" === t ? r = !0 : "component" === t && i.push(n)
                            }), (i = i.map(function(e) {
                                return t[e]
                            })).forEach(function(t) {
                                var n = t.getComputedData();
                                n && e.push({
                                    type: "component",
                                    id: t.id,
                                    data: n
                                })
                            }), r && (a = this.getComputedData(this.publicInstance)), a && e.push({
                                type: "page",
                                data: a
                            }), this.callRemote("self", "receiveData", e, function() {
                                n.forEach(function(e) {
                                    return e()
                                })
                            })
                        }
                    }), e.displayName = o, h = e, e
                })
            },
            E = n(12),
            _ = n(9);
        n.d(t, "d", function() {
            return P
        }), n.d(t, "f", function() {
            return E.b
        }), n.d(t, "b", function() {
            return E.a
        }), n.d(t, "j", function() {
            return E.f
        }), n.d(t, "h", function() {
            return E.d
        }), n.d(t, "i", function() {
            return E.e
        }), n.d(t, "g", function() {
            return E.c
        }), n.d(t, "k", function() {
            return _.a
        }), n.d(t, "m", function() {
            return _.b
        }), n.d(t, "c", function() {
            return A
        }), n.d(t, "a", function() {
            return l.a
        }), n.d(t, "l", function() {
            return O.b
        }), n.d(t, "e", function() {
            return O.a
        })
    }, function(e, t, n) {
        "use strict";

        function a(e) {
            return e && "object" == typeof e ? Object.keys(e) : []
        }
        n.d(t, "a", function() {
            return a
        })
    }, function(e, t, n) {
        "use strict";
        n.d(t, "c", function() {
            return c
        }), n.d(t, "e", function() {
            return s
        }), n.d(t, "d", function() {
            return u
        }), n.d(t, "a", function() {
            return l
        }), n.d(t, "f", function() {
            return g
        }), n.d(t, "b", function() {
            return v
        });
        var a = navigator.userAgent || navigator.swuserAgent,
            r = a.match(/AlipayClient\/(\d+\.\d+\.\d+)/),
            i = a.match(/UCBS\/(\d+\.\d+)/),
            o = r && r[1] || "100.0.0",
            c = (i && i[1], a.indexOf("Android") > -1),
            s = !c,
            u = a.indexOf("AlipayIDE") > -1,
            l = "1.7.1",
            p = {},
            f = {};

        function d(e) {
            if (f[e]) return f[e];
            for (var t = [], n = e.split("."), a = 0; a < n.length; a++) t.push(parseInt(n[a], 10));
            return f[e] = t, t
        }

        function h(e, t) {
            if (e && t) {
                var n = e + "__" + t;
                if (n in p) return p[n];
                e = d(e), t = d(t);
                for (var a, r, i = 0; i < e.length; i++) {
                    if ((a = t[i] || 0) > (r = e[i] || 0)) {
                        p[n] = -1;
                        break
                    }
                    if (a < r) {
                        p[n] = 1;
                        break
                    }
                }
                return p[n] = p[n] || 0, p[n]
            }
            return 0
        }

        function g() {
            console.log("ap/SDKVersion: " + l)
        }

        function v(e) {
            return h(o, e)
        }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return i
        }), n.d(t, "a", function() {
            return c
        });
        var a = n(9);

        function r(e) {
            console.log.apply(console, e)
        }

        function i() {
            if (Object(a.a)().debug) {
                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                r(t)
            }
        }
        var o = {};

        function c(e) {
            if (function(e) {
                    var t = o[e];
                    if (void 0 === t) {
                        var n = Object(a.a)(),
                            r = n.debug;
                        r && (o[e] = t = !!r.match(new RegExp("\\b" + e + "\\b")))
                    }
                    return t
                }(e)) {
                for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) n[i - 1] = arguments[i];
                r(["[" + e + "]"].concat(n))
            }
        }
    }, function(e, t, n) {
        "use strict";
        var a = n(11),
            r = window;
        r.ideMockCallBridge = a.a, r.ideMockAP.callBridge = r.ideMockAP.call, t.a = r.ideMockAP
    }, function(e, t, n) {
        "use strict";
        var a = n(10),
            r = n.n(a),
            i = n(5),
            o = void 0;

        function c(e) {
            Object(i.a)(e).length && (o = e)
        }

        function s() {
            return o
        }
        self.__getStartupParams = s, n.d(t, "a", function() {
            return l
        }), n.d(t, "b", function() {
            return p
        });
        var u = self;

        function l() {
            if (u.__appxStartupParams) return u.__appxStartupParams;
            var e = s();
            if (e) return e;
            var t = location.href,
                n = t.indexOf("?");
            if (e = {}, -1 !== n) {
                var a = t.slice(n + 1);
                c(e = r.a.parse(a))
            }
            return e
        }
        var p = c
    }, function(e, t, n) {
        "use strict";
        var a = n(21),
            r = n(1);

        function i(e, t) {
            return t.encode ? t.strict ? a(e) : encodeURIComponent(e) : e
        }
        t.extract = function(e) {
            return e.split("?")[1] || ""
        }, t.parse = function(e, t) {
            var n = function(e) {
                    var t;
                    switch (e.arrayFormat) {
                        case "index":
                            return function(e, n, a) {
                                t = /\[(\d*)\]$/.exec(e), e = e.replace(/\[\d*\]$/, ""), t ? (void 0 === a[e] && (a[e] = {}), a[e][t[1]] = n) : a[e] = n
                            };
                        case "bracket":
                            return function(e, n, a) {
                                t = /(\[\])$/.exec(e), e = e.replace(/\[\]$/, ""), t ? void 0 !== a[e] ? a[e] = [].concat(a[e], n) : a[e] = [n] : a[e] = n
                            };
                        default:
                            return function(e, t, n) {
                                void 0 !== n[e] ? n[e] = [].concat(n[e], t) : n[e] = t
                            }
                    }
                }(t = r({
                    arrayFormat: "none"
                }, t)),
                a = Object.create(null);
            return "string" != typeof e ? a : (e = e.trim().replace(/^(\?|#|&)/, "")) ? (e.split("&").forEach(function(e) {
                var t = e.replace(/\+/g, " ").split("="),
                    r = t.shift(),
                    i = t.length > 0 ? t.join("=") : void 0;
                i = void 0 === i ? null : decodeURIComponent(i), n(decodeURIComponent(r), i, a)
            }), Object.keys(a).sort().reduce(function(e, t) {
                var n = a[t];
                return Boolean(n) && "object" == typeof n && !Array.isArray(n) ? e[t] = function e(t) {
                    return Array.isArray(t) ? t.sort() : "object" == typeof t ? e(Object.keys(t)).sort(function(e, t) {
                        return Number(e) - Number(t)
                    }).map(function(e) {
                        return t[e]
                    }) : t
                }(n) : e[t] = n, e
            }, Object.create(null))) : a
        }, t.stringify = function(e, t) {
            var n = function(e) {
                switch (e.arrayFormat) {
                    case "index":
                        return function(t, n, a) {
                            return null === n ? [i(t, e), "[", a, "]"].join("") : [i(t, e), "[", i(a, e), "]=", i(n, e)].join("")
                        };
                    case "bracket":
                        return function(t, n) {
                            return null === n ? i(t, e) : [i(t, e), "[]=", i(n, e)].join("")
                        };
                    default:
                        return function(t, n) {
                            return null === n ? i(t, e) : [i(t, e), "=", i(n, e)].join("")
                        }
                }
            }(t = r({
                encode: !0,
                strict: !0,
                arrayFormat: "none"
            }, t));
            return e ? Object.keys(e).sort().map(function(a) {
                var r = e[a];
                if (void 0 === r) return "";
                if (null === r) return i(a, t);
                if (Array.isArray(r)) {
                    var o = [];
                    return r.slice().forEach(function(e) {
                        void 0 !== e && o.push(n(a, e, o.length))
                    }), o.join("&")
                }
                return i(a, t) + "=" + i(r, t)
            }).filter(function(e) {
                return e.length > 0
            }).join("&") : ""
        }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return o
        });
        var a = n(1),
            r = n.n(a),
            i = n(4);

        function o(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                n = t.homepage,
                a = void 0 !== n && n,
                o = t.args,
                c = void 0 === o ? [] : o,
                s = t.caller,
                u = void 0 === s ? "bridge" : s,
                l = Object(i.j)(),
                p = t.page || (a ? l && l[0] : Object(i.h)());
            if (p) {
                var f = [u, e].concat(c),
                    d = f[f.length - 1];
                if (d)
                    if ("object" == typeof d) {
                        var h = d,
                            g = h.success,
                            v = h.fail,
                            b = h.complete;
                        (g || v || b) && (f[f.length - 1] = d = r()({}, d), delete d.success, delete d.fail, delete d.complete, f.push(function() {
                            g && g.apply(void 0, arguments), b && b.apply(void 0, arguments)
                        }), f.push(function() {
                            v && v.apply(void 0, arguments), b && b.apply(void 0, arguments)
                        }))
                    } else "function" == typeof d && f.push(d);
                p.callRemote.apply(p, f)
            } else console.warn("Can not getCurrentPage for callBridge.worker!", e, t)
        }
    }, function(e, t, n) {
        "use strict";
        var a = n(1),
            r = n.n(a),
            i = n(7),
            o = n(3),
            c = n(15),
            s = /#([^?]+)(\?.+)?/,
            u = /[&?]\$pageId=(\d+)$/;

        function l(e) {
            var t = void 0,
                n = e && e.match(s),
                a = n && n[1];
            a && "/" === a.charAt(0) && (a = a.slice(1));
            var r = n && n[2] || "",
                i = r.match(u);
            return i && (t = parseInt(i[1], 10), r = r.replace(u, "")), "?" === r.charAt(0) && (r = r.slice(1)), {
                id: t = t || o.a.tabsConfig[a] || 0,
                page: a,
                queryString: r
            }
        }
        var p = n(10),
            f = n.n(p),
            d = 10,
            h = 100,
            g = h;

        function v(e, t) {
            return t ? o.a.tabsConfig[e] : ++g
        }

        function b(e) {
            var t = e.getId();
            return t >= d && t <= h
        }
        var m = n(5);

        function y(e) {
            var t = e.pagePath,
                n = e.pageId,
                a = e.queryString,
                r = this.getPageById(n);
            if (r) return r;
            var i = c.a.getComponent(t);
            if (!i) throw new Error("[WORKER] page '" + t + "' not found!");
            var o = {};
            return a && (o = f.a.parse(a)), r = i({
                id: n,
                query: o
            }), this._pushPage(r), r
        }

        function I(e, t) {
            var n = this._getPageObject(t),
                a = n.pagePath,
                r = n.queryString,
                i = v(),
                o = y.call(this, {
                    pagePath: a,
                    pageId: i,
                    queryString: r
                });
            return e({
                url: "#" + a + "?$pageId=" + i,
                pagePath: a
            }), o
        }

        function C(e) {
            var t = this,
                n = this.getCurrentPageImpl(),
                a = this._getPageObject(e),
                r = a.pagePath,
                i = a.queryString,
                c = function() {
                    y.call(t, {
                        pagePath: r,
                        pageId: v(r, 1),
                        queryString: i
                    }).fromPage = n
                };
            if (! function() {
                    var e = this;
                    return Object(m.a)(this._tabCaches).every(function(t) {
                        var n = e._tabCaches[t];
                        return !(!n || !n[0]) && b(n[0])
                    })
                }.call(this)) return this._clearAllPages(), void c();
            var s = this._tabCaches[r];
            if ((this._pages || s) && (this._pages !== s || !this._pages || 1 !== this._pages.length)) {
                o.a.dispatchEvent("switchTab", {
                    page: n
                });
                for (var u = this._pages && this._pages.concat() || [], l = u.length - 1; l >= 1; l--) u[l].unload();
                if (this._pages === s) u[0].show();
                else if (1 === u.length && u[0].hide(), this._pages = s, this._pages && this._pages[0]) {
                    var p = this._pages[0];
                    p.fromPage = n, p.show()
                } else c()
            }
        }
        var P = {
            _newPage: y,
            reLaunch: function(e, t) {
                var n = e.url,
                    a = t.pushWindow,
                    r = t.switchTab,
                    i = this.getCurrentPageImpl(),
                    o = this.resolveUrl(n);
                this._clearAllPages();
                v(this._getPageObject(o).pagePath, 1) ? this.switchTab({
                    url: "/" + o
                }, r) : I.call(this, a, o).fromPage = i
            },
            navigateTo: function(e, t) {
                var n = e.url,
                    a = this.getCurrentPageImpl();
                a.hide();
                var r = this.resolveUrl(n);
                I.call(this, t, r).fromPage = a
            },
            redirectTo: function(e, t) {
                var n = e.url,
                    a = this.getCurrentPageImpl(),
                    r = this.resolveUrl(n);
                b(a) ? this._clearAllPages() : a.unload(), I.call(this, t, r).fromPage = a
            },
            switchTab: function(e, t) {
                var n = e.url,
                    a = this.resolveUrl(n),
                    r = this._getPageObject(a).pagePath;
                C.call(this, a), t && t({
                    pagePath: r
                })
            },
            destroyPageByUrl: function(e) {
                var t = l(e).id,
                    n = this._getAllPages();
                if (1 !== n.length || n[0].getId() !== t) {
                    var a = this.getPageById(t);
                    a && a.unload()
                }
            },
            pausePageByUrl: function(e) {
                var t = l(e).id,
                    n = this.getPageById(t);
                n && n.hide()
            },
            resumePageByUrl: function(e) {
                var t = l(e).id,
                    n = this.getPageById(t);
                n && n.show()
            }
        };

        function O(e, t) {
            return e.slice(0, t.length) === t
        }
        var k = {
            resolveUrl: function(e, t) {
                var n = e,
                    a = "",
                    r = n.indexOf("?");
                (-1 !== r && (a = n.slice(r + 1), n = n.slice(0, r)), "/" === n.charAt(0)) ? n = n.slice(1): (t = t || this.getCurrentPageImpl()) && (n = function(e, t) {
                    if (O(e, "/")) return e;
                    O(e, "./") || O(e, "../") || (e = "./" + e);
                    var n = t.split("/");
                    n[n.length - 1] && n.pop();
                    var a = [];
                    return n.concat(e.split("/")).forEach(function(e) {
                        e && "." !== e && (".." === e ? a.pop() : a.push(e))
                    }), a.join("/")
                }(n, t.getPagePath()));
                return "" + n + (a = a ? "?" + a : a)
            }
        };
        n.d(t, "b", function() {
            return E
        }), n.d(t, "a", function() {
            return _
        }), n.d(t, "f", function() {
            return S
        }), n.d(t, "d", function() {
            return R
        }), n.d(t, "e", function() {
            return x
        }), n.d(t, "c", function() {
            return L
        });
        var w = /^on(\w)/;

        function j(e) {
            Object(m.a)(T._tabCaches).forEach(function(t) {
                var n = T._tabCaches[t];
                if (n)
                    for (var a = n.length - 1; a >= 0; a -= 1)
                        if (n[a] === e) return void n.splice(a, 1)
            })
        }
        var T = void 0,
            A = void 0;

        function E() {
            return A
        }

        function _() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            if (T) throw new Error("App() can only be called once");
            return A = e, T = new D(e), o.a.appImpl = T, o.a.dispatchEvent("appCreated", T), A
        }

        function D(e) {
            this.publicInstance = e
        }

        function S() {
            return T._pages || []
        }

        function R() {
            return T && T._pages && T._pages[T._pages.length - 1]
        }

        function x() {
            return (T._pages || []).map(function(e) {
                return e.publicInstance
            })
        }

        function L() {
            return T
        }
        D.prototype = r()({}, k, P, {
            _tabCaches: {},
            _pages: [],
            _pushPage: function(e) {
                T._pages && T._pages.length || (T._tabCaches[e.getPagePath()] = T._pages = []), T._pages.push(e)
            },
            _popPage: j,
            _getAllPages: function() {
                var e = this,
                    t = [];
                return Object(m.a)(this._tabCaches).forEach(function(n) {
                    var a = e._tabCaches[n];
                    a && (t = t.concat(a))
                }), t
            },
            _clearAllPages: function() {
                var e = this._tabCaches || {};
                this._tabCaches = {}, Object(m.a)(e).forEach(function(t) {
                    var n = e[t];
                    n && n.concat().reverse().forEach(function(e) {
                        return e.unload()
                    })
                }), this._pages = []
            },
            fireComponentEvent: function(e, t, n, a) {
                var i, o = e.data,
                    c = o.element,
                    s = l(o.NBPageUrl).id,
                    u = this.getPageById(s);
                if (u) {
                    var p = u.nativeComponents[c];
                    if (p) {
                        var f = p.handlers,
                            d = p.dataset,
                            h = p.componentId,
                            g = f[t];
                        if (g) {
                            var v = r()({
                                timeStamp: Date.now(),
                                type: (i = t, i.replace(w, function(e, t) {
                                    return t.toLowerCase()
                                })),
                                target: {
                                    id: c,
                                    tagName: n,
                                    dataset: d,
                                    targetDataset: d
                                },
                                currentTarget: {
                                    id: c,
                                    tagName: n,
                                    dataset: d
                                }
                            }, a);
                            if (h) {
                                var b = u.getComponentInstance(h);
                                b && b[g] && b[g](v)
                            } else u[g] && u[g](v)
                        }
                    }
                }
            },
            getPageById: function(e) {
                return this.getPageBy(function(t) {
                    return t.getId() === e
                })
            },
            _getPageObject: function(e) {
                var t = e.indexOf("?"),
                    n = "",
                    a = e;
                return -1 !== t && (n = e.slice(t + 1), a = a.slice(0, t)), "/" === a.charAt(0) && (a = a.slice(1)), {
                    queryString: n,
                    pagePath: a
                }
            },
            getPageBy: function(e) {
                for (var t in this._tabCaches)
                    if (this._tabCaches.hasOwnProperty(t)) {
                        var n = this._tabCaches[t];
                        if (n)
                            for (var a = n.length - 1; a >= 0; a -= 1)
                                if (e(n[a])) return n[a]
                    } return null
            },
            launch: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                this.$launchTime = Date.now(), this.launchOptions = e, o.a.dispatchEvent("launch", e), Object(i.b)("framework: App onLaunch"), this.publicInstance.onLaunch && this.publicInstance.onLaunch(e), this.publicInstance.onShow && this.publicInstance.onShow(e)
            },
            hide: function() {
                o.a.dispatchEvent("background"), Object(i.b)("framework: App onHide");
                var e = R();
                e && e.hide(), this.publicInstance.onHide && this.publicInstance.onHide()
            },
            show: function(e) {
                var t = e || {};
                Object(i.b)("framework: App onShow"), o.a.dispatchEvent("foreground", t);
                var n = R();
                n && n.show(), this.publicInstance.onShow && this.publicInstance.onShow(t)
            },
            error: function(e) {
                this.publicInstance.onError && this.publicInstance.onError(e)
            },
            navigateBack: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = arguments[1],
                    n = e.delta,
                    a = void 0 === n ? 1 : n;
                if ("number" != typeof a) return "delta must be number!";
                var r = this.getCurrentPagesImpl().length;
                if (1 === r) return "already top of navigation";
                a >= r && (a = r - 1), t({
                    delta: a
                })
            },
            getCurrentPagesImpl: S,
            getCurrentPageImpl: R
        }), o.a.addEventListener("pageUnload", function(e) {
            j(e.page)
        })
    }, function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        });
        var a = n(14);

        function r(e, t) {
            if (e) {
                for (var n = 0, r = (t = Object(a.a)(t)).length; e && n < r;) e = e[t[n++]];
                return n && n === r ? e : void 0
            }
            return e
        }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return c
        });
        var a = /^\./,
            r = /[^.[\]]+|\[(?:(-?\d+)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
            i = /\\(\\)?/g,
            o = {};

        function c(e) {
            if (o[e]) return o[e];
            var t = [];
            return a.test(e) && t.push(""), e.replace(r, function(e, n, a, r) {
                var o = e;
                a ? o = r.replace(i, "$1") : n && (o = parseInt(n, 10)), t.push(o)
            }), o[e] = t, t
        }
    }, function(e, t, n) {
        "use strict";
        var a = {},
            r = {
                registerComponent: function(e, t) {
                    a[e] = t
                },
                getComponent: function(e) {
                    return a[e] && a[e]()
                }
            };
        t.a = r
    }, function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return d
        }), n.d(t, "a", function() {
            return h
        });
        var a = n(7),
            r = n(12),
            i = n(10),
            o = n.n(i),
            c = n(9),
            s = void 0,
            u = self;
            debugger;
        u.addEventListener("install", function() {
            u.skipWaiting && "function" == typeof u.skipWaiting && u.skipWaiting()
        });
        var l = !0,
            p = [];

        function f(e) {
            Object(a.a)("framework", "[WORKER] App Received Message:", e.data);
            var t = e.data,
                n = t.pagePath,
                i = t.viewId;
            if (n) {
                var u = Object(r.c)(),
                    l = e.data,
                    p = l.queryString,
                    f = l.id,
                    d = u._newPage({
                        pagePath: n,
                        queryString: p,
                        pageId: f
                    });
                if (d.publicInstance.$viewId = i, d.setPort(e.ports[0]), d.$loadTime) return void d.load();
                if (!s) {
                    var h = {
                            path: n
                        },
                        g = Object(c.a)(),
                        v = g.query,
                        b = g.referrerInfo,
                        m = g.ap_framework_sceneId;
                    v && (h.query = o.a.parse(v)), h.scene = m, b && (h.referrerInfo = JSON.parse(b)), s = !0, u.launch(h)
                }
                var y = Object(r.f)();
                y && y[y.length - 1] === d && d.load()
            }
        }

        function d() {
            l = !1
        }

        function h() {
            l = !0, p.forEach(f), p = []
        }
        u.addEventListener("message", function(e) {
            l ? f(e) : p.push(e)
        })
    }, function(e, t, n) {
        e.exports = n(20)
    }, function(e, t) {
        e.exports = function() {}
    }, function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n(2),
            r = n(17),
            i = n.n(r),
            o = n(0),
            c = i.a;
        n.d(t, "ap", function() {
            return a.a
        }), n.d(t, "bridge", function() {
            return i.a
        }), n.d(t, "abridge", function() {
            return c
        }), n.d(t, "WorkerComponent", function() {
            return o.d
        }), n.d(t, "getApp", function() {
            return o.f
        }), n.d(t, "App", function() {
            return o.b
        }), n.d(t, "getCurrentPagesImpl", function() {
            return o.j
        }), n.d(t, "getCurrentPageImpl", function() {
            return o.h
        }), n.d(t, "getCurrentPages", function() {
            return o.i
        }), n.d(t, "getAppImpl", function() {
            return o.g
        }), n.d(t, "getStartupParams", function() {
            return o.k
        }), n.d(t, "setStartupParams", function() {
            return o.m
        }), n.d(t, "Page", function() {
            return o.c
        }), n.d(t, "$global", function() {
            return o.a
        }), n.d(t, "log", function() {
            return o.l
        }), n.d(t, "debug", function() {
            return o.e
        })
    }, function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n(1),
            r = n.n(a),
            i = n(4);

        function o(e) {
            this.config = r()({}, e), this.config.duration = this.config.duration || 400, this.config.timeFunction = this.config.timeFunction || "linear", this.config.transformOrigin = this.config.transformOrigin || "50% 50% 0", this.animations = [], this.currentAnimation = []
        }
        var c = o.prototype = {
            step: function(e) {
                return this.animations.push({
                    config: r()({}, this.config, e),
                    animation: this.currentAnimation
                }), this.currentAnimation = [], this
            },
            export: function() {
                var e = this.animations;
                return this.animations = [], e
            }
        };
        ["opacity", "backgroundColor", "width", "height", "top", "left", "bottom", "right", "rotate", "rotateX", "rotateY", "rotateZ", "rotate3d", "skew", "skewX", "skewY", "scale", "scaleX", "scaleY", "scaleZ", "scale3d", "translate", "translateX", "translateY", "translateZ", "translate3d"].forEach(function(e) {
            c[e] = function() {
                for (var t = arguments.length, n = Array(t), a = 0; a < t; a++) n[a] = arguments[a];
                return this.currentAnimation.push([e, n]), this
            }
        });
        var s = o,
            u = n(11),
            l = n(10),
            p = n.n(l),
            f = self;

        function d(e, t) {
            e.on("appResume", function(n) {
                var a = n.data,
                    r = a.query,
                    o = a.page,
                    c = a.referrerInfo,
                    s = a.ap_framework_sceneId,
                    u = {},
                    l = void 0;
                if (o) {
                    l = o;
                    var d = o.indexOf("?"); - 1 !== d && (l = o.slice(0, d)), u.path = l, i.a.pagesConfig[l] || (e.call("toast", {
                        content: "é¡µé¢å·²å¤±æ•ˆ!",
                        type: "exception"
                    }), f.onerror && f.onerror("Page " + l + " Not Found when appResume"), r = null, o = null, u = {})
                }
                r && (r = p.a.parse(r), u.query = r), c && (u.referrerInfo = JSON.parse(c)), s && (u.scene = s), Object(i.g)().show(u), u.path && ("/" !== o.charAt(0) && (o = "/" + o), t.reLaunch({
                    url: o
                }))
            }), e.on("appPause", function() {
                Object(i.g)().hide()
            }), e.on("beforeDestroy", function(e) {
                var t = e.data.NBPageUrl,
                    n = Object(i.g)();
                n && n.destroyPageByUrl(t)
            }), e.on("pagePause", function(e) {
                var t = e.data.NBPageUrl;
                Object(i.g)().pausePageByUrl(t)
            }), e.on("pageResume", function(e) {
                var t = e.data.NBPageUrl;
                Object(i.g)().resumePageByUrl(t)
            }), e.on("tabClick", function(e) {
                Object(i.g)().switchTab({
                    url: "/" + e.data.tag
                })
            })
        }

        function h() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                t = arguments[1],
                n = e.complete,
                a = e.success,
                r = e.fail;
            t && t.error ? r && r(t) : a && a(t), n && n(t)
        }
        var g = n(8);

        function v(e) {
            var t = e.callBridge;

            function n(e, n) {
                var a = e.pagePath;
                t("switchTab", {
                    tag: a,
                    recreate: n
                })
            }

            function a(e, n) {
                var a = e.url,
                    r = e.pagePath;
                t("pushWindow", {
                    url: a,
                    launchParamsTag: r,
                    param: n
                })
            }
            return {
                reLaunch: function(e) {
                    Object(i.g)().reLaunch({
                        url: e.url
                    }, {
                        pushWindow: function(e) {
                            return a(e, {
                                closeAllWindow: !0,
                                animationType: "none"
                            })
                        },
                        switchTab: function(e) {
                            return n(e, !0)
                        }
                    }), h(e)
                },
                navigateTo: function(e) {
                    Object(i.g)().navigateTo({
                        url: e.url
                    }, a), h(e)
                },
                switchTab: function(e) {
                    Object(i.g)().switchTab({
                        url: e.url
                    }, n), h(e)
                },
                redirectTo: function(e) {
                    Object(i.g)().redirectTo({
                        url: e.url
                    }, function(e) {
                        return a(e, {
                            closeCurrentWindow: !0,
                            animationType: "none"
                        })
                    }), h(e)
                },
                navigateBack: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        n = Object(i.g)().navigateBack({
                            delta: e.delta
                        }, function(e) {
                            var n = e.delta;
                            t("popTo", {
                                index: -n
                            })
                        });
                    n ? h(e, {
                        error: n
                    }) : h(e)
                }
            }
        }
        var b = v(g.a),
            m = r()({
                renderTarget: "web",
                __call: function() {
                    return g.a.call.apply(g.a, arguments)
                },
                __trigger: function() {
                    return g.a.trigger.apply(g.a, arguments)
                },
                call: function() {
                    g.a.callBridge.apply(g.a, arguments)
                }
            }, b, {
                postMessage: function(e) {
                    Object(u.a)("fireMessage", {
                        args: [e]
                    })
                },
                createAnimation: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    return new s(e)
                },
                pageScrollTo: function() {
                    for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                    Object(u.a)("pageScrollTo", {
                        args: t
                    })
                }
            });
        d(g.a, m), i.a.bridge = m;
        var y = m,
            I = n(0);

        function C(e) {
            r()(this, e)
        }

        function P(e, t) {
            var n, a = ["refComponents." + this.element, e];
            if (t) {
                var r = t.success,
                    i = t.fail,
                    o = t.complete;
                a.push(function(e) {
                    r && r(e), o && o(e)
                }, function(e) {
                    i && i(e), o && o(e)
                })
            }(n = this.page).callRemote.apply(n, a)
        }
        C.prototype = {
            getCenterLocation: function(e) {
                P.call(this, "getCenterLocation", e)
            },
            moveToLocation: function() {
                P.call(this, "moveToLocation")
            }
        };
        var O = C,
            k = n(2),
            w = r()({}, k.a, v(k.a), {
                renderTarget: "web"
            });
        d(k.a, w);
        var j = w;
        var T = n(9),
            A = "TAC",
            E = function() {
                return "TinyAppBiz-" + Object(T.a)().appId
            };

        function _(e) {
            var t, n = e || "";
            return !n && Object(I.h)() && (n = Object(I.h)().getPagePath()), {
                spmId: "MiniApp_" + Object(I.k)().appId + "." + (t = n, t.replace(/\./g, "_DOT_")),
                bizType: E()
            }
        }
        var D = n(6);

        function S(e) {
            return e ? "string" == typeof e ? e : Object.keys(e).map(function(t) {
                var n = t + "=";
                return n += String(e[t]).replace(/,/g, ";").replace(/\^/g, "@").replace(/\=/g, "~")
            }).join("^") : ""
        }
        var R = k.a.callInternalAPI,
            x = "setOptionMenu",
            L = "showOptionMenu";
        !D.c && Object(D.b)("10.1.20") >= 0 && (x = "setTAOptionMenu", L = "showTAOptionMenu");
        var M = {
                setOptionMenu: function(e) {
                    R(x, r()({}, e, {
                        bizType: "tiny"
                    })), R(L)
                }
            },
            B = global;

        function U() {
            var e = B.appXAppJson;
            return (e && e.app || {}).$homepage
        }
        var $ = k.a.callBridge,
            N = k.a.callInternalAPI,
            W = "SDKVersion=" + D.a;
        self;

        function F(e) {
            var t = Object(I.h)();
            t && t.publicInstance.onOptionMenuClick && t.publicInstance.onOptionMenuClick(e)
        }
        k.a.on("titleClick", function() {
            var e = Object(I.h)();
            e && e.publicInstance.onTitleClick && e.publicInstance.onTitleClick()
        }), k.a.on("firePullToRefresh", function() {
            var e = Object(I.h)();
            return e && e.pullDownRefresh(), !1
        }), I.a.addEventListener("pageLoad", function(e) {
            var t = e.page,
                n = Object(I.k)(),
                a = n.chInfo,
                i = n.app_startup_type;
            if (I.a.trackerEnabled && $("reportData", {
                    spm: r()({
                        chInfo: a
                    }, _(t.getPagePath())),
                    spmDetail: {
                        app_startup_type: i
                    }
                }), t.publicInstance.onShareAppMessage && (t.startShare = K), M.setOptionMenu) {
                var o = function(e) {
                    var t = self.appXAppJson,
                        n = void 0 === t ? {} : t,
                        a = n[e.getPagePath()],
                        r = n.app;
                    return a && a.optionMenu || r && r.window && r.window.optionMenu
                }(t);
                o && M.setOptionMenu(o)
            }
            var c = U(),
                s = Object.keys(I.a.tabsConfig),
                u = Object(I.j)()[0].getPagePath();
            if (c && u !== c) {
                var l = !0;
                s.length > 0 && s.forEach(function(e) {
                    e === u && (l = !1)
                }), l && $("showBackHome")
            }
        }), k.a.on("onBackHomeClick", function() {
            var e = U();
            e && ("/" !== e.charAt(0) && (e = "/" + e), I.a.bridge.reLaunch({
                url: e
            }))
        }), k.a.on("tinyOptionMenu", F), k.a.on("optionMenu", F), k.a.on("afterShare", function(e) {
            z(e.data)
        }), I.a.addEventListener("launch", function() {
            $("setTabBar", {
                actionType: "enable"
            }), N("onAppPerfEvent", {
                state: "appLoaded"
            }), $("remoteLog", {
                bizType: A,
                type: "behavior",
                actionId: "event",
                seedId: "app.launch",
                param4: W
            })
        }), I.a.addEventListener("foreground", function(e) {
            e && (e._scene || e.scene) && N("onAppPerfEvent", {
                state: "appResume"
            })
        });
        var q = !1;

        function K(e) {
            if (this && this.publicInstance.onShareAppMessage) {
                var t = {};
                e && e.data && e.data.webViewUrl && (t.webViewUrl = e.data.webViewUrl);
                var n = this.publicInstance.onShareAppMessage(t);
                (function(e) {
                    var t = e.path;
                    t || (t = this.getPagePath());
                    "/" === t.charAt(0) && (t = t.slice(1));
                    var n = Object(I.k)().appId,
                        a = {
                            title: e.title,
                            desc: e.desc,
                            url: "alipays://platformapi/startapp?appId=" + n + "&page=" + encodeURIComponent(t)
                        },
                        r = function(t) {
                            z(t), t.shareResult && e.success && e.success(t), !t.shareResult && e.fail && e.fail(t), e.complete && e.complete(t)
                        };
                    $("setToolbarMenu", {
                        menus: [],
                        override: !0
                    }), $("startShare", {
                        bizType: "H5App_DD",
                        sendEvent: !1,
                        onlySelectChannel: ["Weibo", "ALPContact", "ALPTimeLine", "SMS", "Weixin", "WeixinTimeLine", "QQ", "QQZone", "DingTalkSession"]
                    }, function(t) {
                        var i = t.message,
                            o = void 0 === i ? "" : i,
                            c = t.channelName;
                        o.indexOf("canceled") >= 0 || $("getAppInfo", {
                            appId: n,
                            stageCode: ""
                        }, function(t) {
                            var n = t.iconUrl,
                                i = t.name,
                                o = a.url + "&chInfo=ch_share_chsub_" + c,
                                s = {
                                    name: c,
                                    param: {
                                        title: a.title,
                                        content: a.desc,
                                        imageUrl: n,
                                        captureScreen: !1,
                                        url: o,
                                        contentType: "url"
                                    }
                                };
                            if (-1 !== ["Weixin", "QQ", "WeixinTimeLine", "QQZone"].indexOf(c)) {
                                var u = "";
                                e.content && (u = e.content.substring(0, 26)), s.url = "";
                                var l = "";
                                i && (l = "[" + i + "]"), s.param.otherParams = {
                                    bizType: "COMMON_CONFIG",
                                    shareTitle: "",
                                    iconURL: n,
                                    btn1: "å–æ¶ˆ",
                                    btn2: "åŽ»çœ‹çœ‹",
                                    btn2A: o,
                                    preContent: u + "#å±å£ä»¤#é•¿æŒ‰å¤åˆ¶æ­¤æ¡æ¶ˆæ¯ï¼Œæ‰“å¼€æ”¯ä»˜å®å³å¯ä½¿ç”¨" + l + "å°ç¨‹åº"
                                }
                            }
                            if ("Weibo" === c && (s.param.url = "https://ds.alipay.com/?scheme=" + encodeURIComponent(o)), "ALPTimeLine" === c && a.desc && (s.param.title += " - " + a.desc), "ALPContact" === c) {
                                s = {
                                    name: c,
                                    param: {
                                        contentType: "tinyApp",
                                        title: a.title || i,
                                        content: a.desc || "",
                                        url: o,
                                        otherParams: {
                                            appName: i,
                                            appIcon: n,
                                            appType: "å°ç¨‹åº"
                                        }
                                    }
                                };
                                var p = e.imageUrl;
                                p ? N("getShareImageUrl", {
                                    originalImageUrl: p
                                }, function(e) {
                                    e.error ? s.param.imageUrl = p : s.param.imageUrl = e.imageUrl, f()
                                }) : $("snapshot", {
                                    range: D.c ? "embedview" : "screen",
                                    dataType: "fileURL",
                                    saveToGallery: !1
                                }, function(e) {
                                    e.fileURL ? $("uploadImage", {
                                        data: e.fileURL,
                                        dataType: "fileURL",
                                        compress: 3,
                                        business: "multiMedia"
                                    }, function(e) {
                                        e.multimediaID && (s.param.iconUrl = e.multimediaID), f()
                                    }) : f()
                                })
                            } else f();

                            function f() {
                                $("shareToChannel", s, r)
                            }
                        })
                    })
                }).call(this, n)
            } else 0
        }

        function z(e) {
            I.a.trackerEnabled && $("remoteLog", r()({}, _(), {
                actionId: "auto_share",
                param4: S({
                    SDKVersion: D.a,
                    channel: e.channelName,
                    shareResult: e.shareResult
                })
            }))
        }
        I.a.addEventListener("pageReady", function(e) {
            var t = e.page,
                n = {
                    state: "pageLoaded",
                    page: t.getPagePath()
                };
            q ? n.loadTime = Date.now() - t.$startTime : q = !0, N("onAppPerfEvent", n)
        }), k.a.on("onShare", function(e) {
            var t = Object(I.h)();
            K.call(t, e)
        });
        var H = n(13);

        function X(e, t) {
            if (e) {
                var n = {};
                return Object.keys(t).forEach(function(a) {
                    n[a] = Object(H.a)(e, t[a])
                }), n
            }
        }
        var J = k.a.callBridge,
            V = I.a.trackerDataBuffer = {},
            G = void 0,
            Q = void 0;

        function Y(e) {
            return S(r()({}, e, {
                SDKVersion: D.a,
                appId: Object(I.k)().appId
            }))
        }

        function Z(e) {
            var t = e.page;
            if (t) {
                var n = t.getPagePath(),
                    a = function(e) {
                        var t = I.a.trackerConfig,
                            n = I.a.trackerEnabled;
                        if (!t || !n) return;
                        if (e in re) return re[e];
                        var a = void 0;
                        return t.forEach(function(t) {
                            var n = void 0,
                                r = {
                                    eventCode: t.eventCode,
                                    eventTarget: []
                                };
                            t.eventTarget.forEach(function(t) {
                                var a = t.page || "";
                                "/" === a.charAt(0) && (a = a.slice(1)), a !== e && "ANY_PAGE" !== a || "click" !== t.trigger || (n = r).eventTarget.push(t)
                            }), n && (a = a || []).push(n)
                        }), re[e] = a, a
                    }(n);
                t.trackerConfig !== a && (t.trackerConfig = a, Object(I.e)("framework", "[WORKER] push trackerConfig to page:", n, a), t.callRemote("bridge", "setTrackerConfig", a))
            }
        }
        I.a.trackerEnabled = !0;
        var ee = {
            first: !0
        };
        I.a.addEventListener("launch", function() {
            var e, t;
            e = function(e) {
                ae(e)
            }, t = Object(I.k)().appId, J("trackerConfig", {
                requestType: "isTrackerEnable",
                params: {
                    appId: t
                }
            }, function() {
                var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                Object(I.e)("framework", "[WORKER] isTrackerEnable", n), n.error ? I.a.trackerEnabled = !0 : I.a.trackerEnabled = n.enable || !1, J("trackerConfig", {
                    requestType: "queryTrackerConfig",
                    params: {
                        appId: t
                    }
                }, function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    if (t && !t.error) {
                        Object(I.l)("framework: getTrackerConfig", t);
                        var n = t.config,
                            a = void 0 === n ? [] : n,
                            r = t.env,
                            i = void 0 === r ? "release" : r;
                        I.a.trackerConfig = a, I.a.trackerEnv = i, e(I.a.trackerEnabled ? a : [])
                    }
                })
            })
        }, ee), k.a.on("afterShare", function(e) {
            I.a.dispatchEvent("afterShare", {
                page: Object(I.h)(),
                event: e
            })
        }), k.a.on("onShare", function() {
            I.a.dispatchEvent("share", {
                page: Object(I.h)()
            })
        });
        var te = {},
            ne = !1;

        function ae(e) {
            Z({
                page: Object(I.h)()
            });
            var t = {};
            e.forEach(function(e) {
                e.eventTarget.forEach(function(n) {
                    var a = n.trigger;
                    "click" !== a && (t[a] = t[a] || [], t[a].push({
                        eventCode: e.eventCode,
                        eventTarget: n
                    }))
                })
            }), Object.keys(te).forEach(function(e) {
                te[e](), delete te[e]
            }), Object.keys(t).forEach(function(e) {
                var n = t[e];
                if (n && n.length) {
                    var a = function() {
                            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                a = t.page,
                                i = t.params;
                            n.forEach(function(t) {
                                var n = t.eventCode,
                                    o = t.eventTarget,
                                    c = o.page;
                                "ANY_PAGE" !== c && c && a && a.getPagePath() !== c || G[o.action](a, n, {
                                    dataConfig: o.data,
                                    params: r()({}, i, {
                                        $appTrigger: e
                                    })
                                })
                            })
                        },
                        i = function() {
                            var e = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).page;
                            a({
                                page: e
                            })
                        };
                    if ("launch" === e) ne || (i(), ne = !0);
                    else if ("afterShare" === e) {
                        te[e] = I.a.addEventListener(e, function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                t = e.page,
                                n = e.event;
                            a({
                                page: t,
                                params: {
                                    shareResult: n.data.shareResult
                                }
                            })
                        }, ee)
                    } else te[e] = I.a.addEventListener(e, i, ee)
                }
            })
        }
        k.a.on("onTrackerConfigChange", function(e) {
            var t = e && e.data && e.data.config || [];
            I.a.trackerConfig = t, re = {}, Object(I.l)("framework: onTrackerConfigChange", e), ae(I.a.trackerEnabled ? t : [])
        }), k.a.on("onTrackerEnableChange", function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                t = e.enable;
            I.a.trackerEnabled = t, Object(I.l)("framework: onTrackerEnableChange", e), ae(t ? I.a.trackerConfig : [])
        });
        var re = {};
        I.a.addEventListener("enterPage", Z, ee), G = {
            collect: (Q = {
                collectTrackerData: function(e, t, n) {
                    var a = n.dataConfig,
                        i = n.params,
                        o = void 0 === i ? {} : i;
                    if (I.a.trackerEnabled) {
                        var c = Object(I.g)(),
                            s = e && e.getId ? e : c.getPageById(e) || Object(I.h)(),
                            u = (Object(I.j)(), {}),
                            l = {},
                            p = Date.now();
                        Object.keys(a).forEach(function(e) {
                            var t, n, r = a[e];
                            "$PAGE_TIME" !== r ? "$APP_TIME" !== r ? "$CURRENT_PAGE" !== r ? "$LAST_PAGE" !== r ? (n = "$APP.", (t = r) && t.slice(0, n.length) === n ? l[e] = r.slice("$APP.".length) : u[e] = r) : o[e] = s.fromPage && s.fromPage.getPagePath() : o[e] = s && s.getPagePath() : o[e] = p - c.$launchTime : o[e] = p - s.$loadTime
                        });
                        var f = s && X(s.publicInstance.data, u),
                            d = X(c.publicInstance.globalData, l);
                        V[t] = r()({}, V[t], f, o, d)
                    }
                },
                reportTrackerData: function(e, t, n) {
                    var a = n.dataConfig,
                        r = n.params;
                    if (I.a.trackerEnabled) {
                        Q.collectTrackerData(e, t, {
                            dataConfig: a,
                            params: r
                        });
                        var i = V[t],
                            o = Object(I.k)().appId;
                        J("remoteLog", {
                            bizType: E(),
                            seedId: t,
                            actionId: "event",
                            param4: Y(i)
                        }), J("trackerConfig", {
                            requestType: "triggerUpload",
                            params: {
                                appId: o,
                                env: I.a.trackerEnv
                            }
                        }), Object(I.e)("framework", "[WORKER] reportTrackerData", t, i, o), V[t] = {}
                    }
                }
            }).collectTrackerData,
            report: Q.reportTrackerData
        };
        var ie = {
                reportAnalytics: function(e, t) {
                    J("remoteLog", {
                        spmId: e,
                        param4: Y(t),
                        type: "behavior",
                        bizType: E(),
                        actionId: "event",
                        logLevel: 1
                    })
                },
                $trackerAPI: Q
            },
            oe = ["fillStyle", "strokeStyle", "globalAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "textBaseline", "lineDashOffset", "textAlign", "font"],
            ce = [].concat(oe, ["shadow", "fontSize"]);

        function se(e, t) {
            this.actions = [], this.callId = 0, this.id = e, this.page = t;
            var n = this;
            ce.forEach(function(e) {
                Object.defineProperty(n, e, {
                    configurable: !0,
                    set: function(t) {
                        n["set" + e.charAt(0).toUpperCase() + e.slice(1)](t)
                    }
                })
            })
        }
        var ue = se.prototype = {
            draw: function(e) {
                this.page.callRemote("refComponents." + this.id, "draw", this.actions, e), this.actions = []
            },
            toTempFilePath: function() {
                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                Object(u.a)("toTempFilePath", {
                    page: this.page,
                    caller: "refComponents." + this.id,
                    args: t
                })
            },
            setShadow: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                    n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                    a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "black";
                this.actions = this.actions.concat([{
                    property: "shadowOffsetX",
                    value: e
                }, {
                    property: "shadowOffsetY",
                    value: t
                }, {
                    property: "shadowBlur",
                    value: n
                }, {
                    property: "shadowColor",
                    value: a
                }])
            },
            setFontSize: function(e) {
                this.actions.push({
                    property: "font",
                    value: e + "px Arial"
                })
            },
            createPattern: function() {
                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                return this.actions.push({
                    action: "createPattern",
                    callId: ++this.callId,
                    args: t
                }), {
                    $callId: this.callId
                }
            }
        };
        oe.forEach(function(e) {
            var t = e.charAt(0).toUpperCase() + e.slice(1);
            ue["set" + t] = function(t) {
                this.actions.push({
                    property: e,
                    value: t
                })
            }
        }), ["createLinearGradient", "createRadialGradient", "createCircularGradient"].forEach(function(e) {
            ue[e] = function() {
                for (var t = arguments.length, n = Array(t), a = 0; a < t; a++) n[a] = arguments[a];
                var r = n,
                    i = e;
                "createCircularGradient" === i && (i = "createRadialGradient", r = [r[0], r[1], 0, r[0], r[1], r[2]]);
                var o = [];
                return this.actions.push({
                    action: i,
                    nested: o,
                    callId: ++this.callId,
                    args: r
                }), {
                    $callId: this.callId,
                    addColorStop: function() {
                        for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                        o.push({
                            action: "addColorStop",
                            args: t
                        })
                    }
                }
            }
        }), ["clip", "fill", "rect", "fillRect", "strokeRect", "stroke", "scale", "rotate", "translate", "save", "restore", "clearRect", "fillText", "drawImage", "moveTo", "lineTo", "arcTo", "arc", "transform", "setTransform", "stroke", "beginPath", "closePath", "quadraticCurveTo", "bezierCurveTo", "setLineDash", "strokeText"].forEach(function(e) {
            ue[e] = function() {
                for (var t = arguments.length, n = Array(t), a = 0; a < t; a++) n[a] = arguments[a];
                this.actions.push({
                    action: e,
                    args: n
                })
            }
        });
        var le = {
            canvasToTempFilePath: function() {
                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                Object(u.a)("toTempFilePath", {
                    caller: "refComponents." + t[0].canvasId,
                    args: t
                })
            },
            createCanvasContext: function(e) {
                return new se(e, Object(I.h)())
            }
        };

        function pe(e, t) {
            this.id = e, this.page = t
        }
        var fe = pe.prototype;
        ["sendDanmu", "play", "pause", "seek"].forEach(function(e) {
            fe[e] = function() {
                for (var t, n = arguments.length, a = Array(n), r = 0; r < n; r++) a[r] = arguments[r];
                (t = this.page).callRemote.apply(t, ["refComponents." + this.id, e].concat(a))
            }
        });
        var de = {
            createVideoContext: function(e) {
                return new pe(e, Object(I.h)())
            }
        };

        function he(e, t) {
            this.id = e, this.page = t
        }
        var ge = he.prototype;
        ["play", "pause", "seek", "setSrc"].forEach(function(e) {
            ge[e] = function() {
                for (var t, n = arguments.length, a = Array(n), r = 0; r < n; r++) a[r] = arguments[r];
                (t = this.page).callRemote.apply(t, ["refComponents." + this.id, e].concat(a))
            }
        });
        var ve = {
                createAudioContext: function(e) {
                    return new he(e, Object(I.h)())
                }
            },
            be = k.a.callBridge,
            me = k.a.callInternalAPI,
            ye = "SDKVersion=" + D.a,
            Ie = "digest",
            Ce = "all";

        function Pe(e) {
            be("remoteLog", e)
        }

        function Oe(e, t, n) {
            var a = "my." + e + ".success";
            switch (Ie) {
                case "digest":
                    Pe({
                        bizType: A,
                        type: "behavior",
                        actionId: "event",
                        seedId: a,
                        param4: ye
                    });
                    break;
                case "all":
                    Pe({
                        bizType: A,
                        type: "behavior",
                        actionId: "event",
                        seedId: a,
                        param2: S(t),
                        param3: S(n),
                        param4: ye
                    });
                default:
                    return
            }
        }

        function ke(e, t, n) {
            var a = "my." + e + ".fail";
            switch (Ce) {
                case "digest":
                    Pe({
                        bizType: A,
                        type: "behavior",
                        actionId: "event",
                        seedId: a,
                        param4: ye
                    });
                    break;
                case "all":
                    Pe({
                        bizType: A,
                        type: "behavior",
                        actionId: "event",
                        seedId: a,
                        param2: S(t),
                        param3: S(n),
                        param4: ye
                    });
                default:
                    return
            }
        }

        function we(e) {
            return e.error && e.error < 0
        }
        me("getConfig4Appx", {
            key: "tinyApLogLevel"
        }, function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            if (e.configKey) {
                var t = void 0;
                try {
                    t = JSON.parse(e.configKey)
                } catch (e) {
                    console.error(e)
                }
                t && (Ie = t.apicall || Ie, Ce = t.exception || Ce)
            }
        });
        var je = {
            component: 1,
            page: {
                onOptionMenuClick: 1,
                setData: {
                    callback: 1
                }
            },
            getLocation: {
                object: {
                    type: 1
                }
            },
            button: {
                "open-type": {
                    share: 1
                }
            },
            datePicker: {
                object: {
                    format: {
                        yyyy: 1,
                        "yyyy-MM": 1
                    }
                }
            },
            getSystemInfo: {
                return: {
                    storage: 1,
                    currentBattery: 1,
                    brand: 1,
                    fontSizeSetting: 1
                }
            },
            form: {
                "report-submit": 1
            },
            lifestyle: 1,
            connectSocket: {
                object: {
                    protocols: 1
                }
            },
            closeSocket: {
                object: {
                    code: 1,
                    reason: 1
                }
            },
            "contact-button": {
                "ext-info": 1
            },
            "web-view": Object(D.b)("10.1.20") >= 0
        };
        var Te = n(18),
            Ae = n.n(Te),
            Ee = function() {
                function e(t) {
                    Ae()(this, e), this.actions = [], this.page = t
                }
                return e.prototype.select = function(e) {
                    return this.selector = {
                        value: e
                    }, this
                }, e.prototype.selectAll = function(e) {
                    return this.selector = {
                        value: e,
                        type: "all"
                    }, this
                }, e.prototype.selectViewport = function() {
                    return this.selector = {
                        value: "viewport"
                    }, this
                }, e.prototype.boundingClientRect = function() {
                    return this.selector && (this.actions.push({
                        selector: this.selector,
                        type: "rect"
                    }), this.selector = null), this
                }, e.prototype.scrollOffset = function() {
                    return this.selector && (this.actions.push({
                        selector: this.selector,
                        type: "scroll"
                    }), this.selector = null), this
                }, e.prototype.exec = function(e) {
                    var t = this.page || Object(I.h)();
                    t && t.callRemote("bridge", "createSelectorQuery", this.actions, e)
                }, e
            }();
        var _e = void 0,
            De = function(e) {
                e.referrerInfo && !e.referrerInfo._back && (_e = e.referrerInfo.appId)
            };
        I.a.addEventListener("foreground", De), I.a.addEventListener("launch", De);
        var Se = {
            navigateToMiniProgram: function(e) {
                var t = {
                        appId: Object(I.k)().appId
                    },
                    n = {};
                e.path && (n.page = e.path), e.extraData && (t.extraData = e.extraData), n.referrerInfo = JSON.stringify(t), k.a.callBridge("navigateToMiniProgram", {
                    appId: e.appId,
                    param: n
                })
            },
            navigateBackMiniProgram: function(e) {
                if (_e) {
                    var t = {
                        _back: 1,
                        appId: Object(I.k)().appId
                    };
                    e.extraData && (t.extraData = e.extraData), k.a.callBridge("navigateBackMiniProgram", {
                        appId: _e,
                        closeCurrentApp: !0,
                        param: {
                            referrerInfo: JSON.stringify(t)
                        }
                    }), _e = null
                }
            }
        };
        var Re, xe = k.a.callBridge,
            Le = k.a.callInternalAPI,
            Me = self,
            Be = Me.appXRuntimeConfig,
            Ue = void 0 === Be ? {} : Be,
            $e = ["pushWindow", "openInBrowser", "internalAPI", "resizeNativeKeyBoardInput"],
            Ne = r()({}, y, {
                SDKVersion: D.a,
                getExtConfigSync: function() {
                    return Me.appXAppJson && Me.appXAppJson.app && Me.appXAppJson.app.ext
                },
                navigateTo: function(e) {
                    (function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                            t = self.appXRuntimeConfig,
                            n = t && t.navigationStackLimits || 10;
                        if (Object(I.j)().length >= n) {
                            var a = e.fail,
                                r = e.complete,
                                i = {
                                    error: 1,
                                    errorMessage: "depth can not be more than 5"
                                };
                            return a && a(i), r && r(i), !0
                        }
                        return !1
                    })(e) || y.navigateTo(e)
                },
                canIUse: function(e) {
                    return function(e, t) {
                        var n = t.split(".");
                        if (1 === n.length && e[n[0]]) return !0;
                        for (var a = je, r = 0; r < n.length; r++)
                            if (!(a = a[n[r]])) return !1;
                        return !0
                    }(Ne, e)
                }
            }, le, ve, de, ie, {
                createSelectorQuery: function() {
                    var e = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).page;
                    return new Ee(e)
                }
            }, Se, M, {
                createMapContext: function(e) {
                    return new O({
                        element: e,
                        page: Object(I.h)()
                    })
                },
                stopPullDownRefresh: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = void 0,
                        n = e.page;
                    n && (t = {
                            viewId: n.$viewId
                        }), xe("restorePullToRefresh", t),
                        function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                t = arguments[1],
                                n = e.complete,
                                a = e.success,
                                r = e.fail;
                            t && t.error ? r && r(t) : a && a(t), n && n(t)
                        }(e)
                },
                hideKeyboard: function() {
                    var e = void 0,
                        t = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).page;
                    t && (e = {
                        viewId: t.$viewId
                    }), Le("hideCustomKeyBoard", e), (t || Object(I.h)()).callRemote("bridge", "hideKeyboard")
                }
            }, j, {
                call: function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        n = arguments[2];
                    if (!1 === Ue.blacklistAPI || -1 === $e.indexOf(e)) {
                        var a = t,
                            i = n;
                        "function" == typeof a && (i = a, a = {});
                        var o = r()({}, a);
                        o.page && (o.viewId = o.page.$viewId, delete o.page), o.success && delete o.success, o.fail && delete o.fail, o.complete && delete o.complete, xe(e, o, function(e) {
                            e && e.error ? a.fail && a.fail(e) : a.success && a.success(e), a.complete && a.complete(e), i && i(e)
                        })
                    }
                }
            }),
            We = 0,
            Fe = 0;
        k.a.on("titleClick", function() {
            var e = Date.now();
            e - Fe < 250 ? 5 === ++We && (We = 0, Ne.alert({
                title: Ne.SDKVersion
            })) : We = 0, Fe = e
        }), Re = Ne, k.a.on("nbcomponent.webview.onFromMessage", function(e) {
            var t = e.viewId,
                n = e.data,
                a = n.callback,
                i = n.type,
                o = n.param,
                c = n.element;
            if (["navigateTo", "navigateBack", "switchTab", "reLaunch", "redirectTo", "getLocation"].indexOf(i) > -1) {
                var s = r()({}, o, {
                    complete: function(e) {
                        k.a.call("NBComponent.sendMessage", {
                            actionType: "postMessage",
                            viewId: t,
                            element: c,
                            data: {
                                callback: a,
                                res: {
                                    type: "response",
                                    res: e
                                }
                            }
                        })
                    }
                });
                Re[i](s)
            }
        }), Ne = function(e) {
            var t = ["canIUse", "postMessage", "call", "createAnimation", "createMapContext", "pageScrollTo", "createCanvasContext", "createAudioContext", "createVideoContext", "reportAnalytics"];
            return Object.keys(e).reduce(function(n, a) {
                return -1 === t.indexOf(a) && "function" == typeof e[a] ? n[a] = function(t) {
                    if ("object" != typeof t) return e[a](t);
                    var n = r()({}, t);
                    if (delete n.fail, delete n.success, function(e, t) {
                            var n = "my." + e + ".call";
                            switch (Ie) {
                                case "digest":
                                    Pe({
                                        bizType: A,
                                        type: "behavior",
                                        actionId: "event",
                                        seedId: n,
                                        param4: ye
                                    });
                                    break;
                                case "all":
                                    Pe({
                                        bizType: A,
                                        type: "behavior",
                                        actionId: "event",
                                        seedId: n,
                                        param2: S(t),
                                        param4: ye
                                    })
                            }
                        }(a, n), /^.+Sync$/.test(a)) {
                        var i = e[a].call(e, t) || {};
                        if (i.error || i.errorMessage) {
                            if (we(i)) return i;
                            ke(a, n, i)
                        } else Oe(a, n, i);
                        return i
                    }
                    var o = (t = t || {}).success;
                    t.success = function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        Oe(a, n, e), "function" == typeof o && o(e)
                    };
                    var c = t.fail;
                    return t.fail = function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        we(e) || ke(a, n, e), "function" == typeof c && c(e)
                    }, e[a](t)
                } : n[a] = e[a], n
            }, {})
        }(Ne), Object(D.f)(), I.a.bridge = Ne;
        t.default = Ne
    }, function(e, t, n) {
        "use strict";
        e.exports = function(e) {
            return encodeURIComponent(e).replace(/[!'()*]/g, function(e) {
                return "%" + e.charCodeAt(0).toString(16).toUpperCase()
            })
        }
    }, function(e, t, n) {
        e.exports = n(19)
    }]),
    __appxCosts = Date.now() - __appxStartTime;
AFAppX.ap.callInternalAPI("onAppPerfEvent", {
    state: "workerFrameworkLoaded",
    loadTime: __appxCosts
}), console.log("framework: worker bundle costs " + __appxCosts + " ms");

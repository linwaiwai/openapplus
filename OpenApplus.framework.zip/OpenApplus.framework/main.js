window = (function(){
  var __callback = {};
  var callbackId = 1;
  var that = this;
  // window.ideMockBridge = {}; // bridge 及bridge.call问题
// todo: delete
/*window.ideMockCallBridge = (_, { args: [name, params] }) => {
 _ideTemplate(name, params, params.success, params.fail);
 };*/
  return {
        ideMockBridge:{
            call :function (method, options, callback) {
                console.log(method);
            }
        },
        ideMockAP: {
            getSystemInfoSync :function(){
                return this.callInternalAPISync("getSystemInfoSync");
            },
            getStorageSync :function(key){
                return this.callInternalAPISync("getStorageSync",{key:key});
            },
            setStorageSync :function(key, data){
                this.callInternalAPISync("getStorageSync",{
                    key:key,
                    data:data
                });
            },
            getUserInfo :function(params){
                this.call('getUserInfo', params, function(res){
                    if (res.error){
                        params.fail && params.fail(res);
                    } else {
                        params.success && params.success(res);
                    }
                })
            },
            login :function(params){
                this.call('login', params, function(res){
                    if (res.error){
                        params.fail && params.fail(res);
                    } else {
                        params.success && params.success(res);
                    }
                })
            },
            request:function(params){
                this.call('request', params, function(res){
                     if (res.error){
                        params.fail && params.fail(res);
                    } else {
                        params.success && params.success(res);
                    }
                })
            },
            callBridgeSync: function(event, data){
                console.debug("callInternalAPISync : "+ event + " withParam:" + JSON.stringify(data));
                return callAPISync(event, data);
            },
            simulated: false,
            on: function (event, fn) {
                self.AlipayJSBridge.on(event,fn);
            },
            call: function (event, params, callback) {
                self.AlipayJSBridge.call(event,params, callback);
            }
        }
    };
})();
